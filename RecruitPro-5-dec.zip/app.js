$(document).ready(function(){
    const header = document.getElementsByTagName('header');

    const menu = document.querySelector('.menu')
    const cancel = document.querySelector('.cancel')

    if(menu){
        menu.addEventListener('click',e=>{
            header.classList.add('mobile-menu-active')
        })
    }
    if($(window).width() < 831){
    $('.hamburger').on('click', function(){
        $(this).parents('body').addClass('mobile-menu-open');
        $('nav').show();
    });

    $(document).click(function(event) {
        var target = $(event.target);
        if (!target.closest('nav').length && !target.closest('.hamburger').length) {
            $('nav').hide();
            $('body').removeClass('mobile-menu-open');
        }
    });

    $('.menu-close').click(function(event){
        // var target = $(event.target);
        // if (!target.closest('nav').length && !target.closest('.hamburger').length) {
        //     $('nav').hide();
        //     $('body').removeClass('mobile-menu-open');
        // }
        $('body').removeClass('mobile-menu-open');
    })

}

if($(window).width() < 831){
    $('header nav > ul > li').each(function(){
        $(this).click(function(){
           // $('header nav > ul > li ul.sub-menu').hide();
            if($(this).find('ul.sub-menu').length > 0){
                $(this).toggleClass('open')
                $(this).find('ul.sub-menu').toggle();
            }
        })
    })
}


    if($(window).width() > 832){
        $('.hamburger').on('click', function(){
            // $('.navcontainer .nav ')
        });
    }
})






